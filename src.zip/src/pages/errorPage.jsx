

export default function ErrorPage() {

  
  return (
    <h1>There was an error</h1>
  );
}